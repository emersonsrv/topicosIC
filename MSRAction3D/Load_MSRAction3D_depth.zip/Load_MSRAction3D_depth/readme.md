Copyright (c) 2017 Josué Rocha Lima - Centro Federal de Educação
Tecnologica de Minas Gerais - josuerocha@me.com - github.com/josuerocha

showDepthMap - function that shows a single depth map
loadDepthMap - loads a depth map file from MSR Action3D dataset
showDepthSequence - shows action as a video MATLAB viewer

